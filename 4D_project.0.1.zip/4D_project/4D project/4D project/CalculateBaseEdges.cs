﻿using System;


namespace Generator
{
    public class CalculateBaseEdges
    {
        //uses array verticesBase to calculate which vertices belong to each edge
        public static int[,] calculateBaseEdges(int[,] verticesBase)
        {
            int noOfVertices = verticesBase.GetLength(0);
            int noOfDimensions = verticesBase.GetLength(1);
            //counts matches of values in vertices
            int Success = 0;
            //creates empty array for entries
            int[,] edgesBase = new int[(int)Math.Pow(2, (noOfDimensions - 1)) * noOfDimensions, 2];
            //first entry at 0
            int edgesPosistion = 0;
            //check every vertex 
            for (int j = 0; j < noOfVertices - 1; j++)
            {
                //against every vertex with higher entry point in array
                for (int k = j + 1; k < noOfVertices; k++)
                {
                    //for every axis
                    for (int i = 0; i < noOfDimensions; i++)
                    {
                        //if both x, y, z..... coordinates match
                        if (verticesBase[j, i] == verticesBase[k, i])
                        {
                            //add 1 to success value
                            Success++;
                        }
                        //if all but one coordinate matched then these 2 vertices form an edge
                        if (Success == noOfDimensions-1)
                        {
                            //position of first vertex on verticesBase array
                            edgesBase[edgesPosistion, 0] = j;
                            //position of second vertex on verticesBase array
                            edgesBase[edgesPosistion, 1] = k;
                            //increase entry point on edgeBase array
                            edgesPosistion++;
                            //set count back to 0
                            Success = 0;

                        }
                        
                    }
                    //set count back to 0 (this is needed for when a match is not formed)
                    Success = 0;                    

                }
                
            }
            return edgesBase;
        }
    }
}
