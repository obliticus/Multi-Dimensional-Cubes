﻿using System;



namespace Generator
{

    public class CalculateVertices
    {

        public static float[,] calculateVertices(float[] verticesRotationMultiplier, int[,] verticesBase, int hyperCubeLength)
        {
            //define size of vertex array
            int noOfVertices = verticesBase.GetLength(0);
            int noOfDimensions = verticesBase.GetLength(1);
            
            //create vertex array 
            float[,] verticesNew = new float[noOfVertices, noOfDimensions];

            //sets each value = to half the length of an edge then accounts for it's rotation
            for (int i = 0; i < noOfVertices; i++)
            {
                for (int j = 0; j < noOfDimensions; j++)
                {
                   
                    verticesNew[i, j] = verticesBase[i,j] * (hyperCubeLength / 2) * verticesRotationMultiplier[j];
                  
                }
            }

            return verticesNew;
        }
    }



}

