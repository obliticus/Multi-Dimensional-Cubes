﻿using System;

namespace Generator
{
    public class UserInput
    {
        public int[] userInput()
        {
            //userInputData(0) = noOfDimensions
            //userInputData(1) = hyperCubeLength
            //userInputData(2) = angleOfRotation
            //userInputData(3) = rotationPlaneOne
            //userInputData(4) = rotationPlaneTwo
            int[] userInputData = new int[5] { 0, 0, 360, 0, 0 };
            int hyperCubeLengthInput;
            int noOfDimensionsInput;
            int angleDegreesInput;

            Console.WriteLine("How Many Dimensions 1-9?");
            //until acceptable input gathered
            while (userInputData[0] == 0)
            {
                //read integer input
                noOfDimensionsInput = Convert.ToInt16(Console.ReadLine());
                //if integer between 0 & 10
                if ((noOfDimensionsInput > 0) && (noOfDimensionsInput < 10))
                {
                    //save input
                    userInputData[0] = noOfDimensionsInput;
                    
                }
                else
                {
                    //tell user of error and readline
                    Console.WriteLine("Must be an Integer between 0 and 10\n");
                }
            }
            //ask for input on same line
            Console.Write("how long is an edge on your hypercube?\n Must be between 0 and 100\n");
            //until acceptable input gathered
            while (userInputData[1] == 0)
            {
                hyperCubeLengthInput = Convert.ToInt16(Console.ReadLine());
                if ((hyperCubeLengthInput > 0) && (hyperCubeLengthInput <= 100))
                {
                    //save user input
                    userInputData[1] = hyperCubeLengthInput;
                    
                    // ED: Use string formatting like above OR + to add things together in a string
                    //Console.WriteLine("Hypercube length = " + userInputData[1] + " say something else, here's a variable" + userInputData[0]);
                }
                else
                {
                    //error message
                    Console.WriteLine("\nMust be positive integer 100 or less");
                }
            }
            //get angle of rotation
            Console.Write("What is the angle of rotation in degrees?\n");
            while (userInputData[2] == 360)
            {
                angleDegreesInput = Convert.ToInt16(Console.ReadLine());
                if ((angleDegreesInput > 0) && (angleDegreesInput <= 360))
                {
                    //save user input
                    userInputData[2] = angleDegreesInput;
                    Console.WriteLine("angle = {0}", userInputData[2]);
                }
                else
                {
                    //error message
                    Console.WriteLine("Must be an integer between 0 and 360");
                }
            }
            Console.Write("Choose 2 axis to rotate by entering an integer\nX = 0, Y = 1, Z = 2.....\n");
            userInputData[3] = userInputData[0];
            userInputData[4] = userInputData[0];
            while (userInputData[3] == userInputData[0])
            //get 2 axis to rotate in
            {
                int rotationPlaneOneInput = Convert.ToInt16(Console.ReadLine());
                if ((rotationPlaneOneInput >= 0) && (rotationPlaneOneInput < userInputData[0]))
                {
                    //save user input
                    userInputData[3] = rotationPlaneOneInput;
                    
                }
                else
                {
                    //error message
                    Console.WriteLine("Must be an integer from 0 and less than number of dimensions");
                }
            }
            while (userInputData[4] == userInputData[0])
            {
                int rotationPlaneTwoInput = Convert.ToInt16(Console.ReadLine());
                if ((rotationPlaneTwoInput >= 0) && (rotationPlaneTwoInput < userInputData[0] && userInputData[3] != rotationPlaneTwoInput))
                {
                    //save user input
                    userInputData[4] = rotationPlaneTwoInput;
                    
                }
                else
                {
                    //error message
                    Console.WriteLine("Must be an integer from 0 and less than number of dimensions and not equal to first axis");
                }
            }
            Console.WriteLine("\n");
            return userInputData;

        }
    }
}

    //class WriteCoordsToVerticesNew
    //for (i=0; i<noOfDimensions; i++)
    //verticesNew(verticesNewPosition,i) = vertexCalculator(i)*(userInputData(1)/2)*(verticesRotationMultiplier(i))
    //verticesNewPosition++

