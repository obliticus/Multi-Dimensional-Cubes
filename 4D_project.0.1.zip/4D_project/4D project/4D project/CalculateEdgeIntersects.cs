﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Generator
{
    public class CalculateEdgeIntersects
    {
        public float[,] calculateEdgeIntersects(int[,] edgesBaseInput, float[,] verticesInput)
        {
            int [,] edgesBase = edgesBaseInput;
            float[,] vertices = verticesInput;
            float[,] intersectVertices = new float [1,1];
            return intersectVertices;
        }
        
    }
}
