﻿using System;

namespace Generator
{

    public class CalculateBaseVertices
    {
       
        public static int[,] calculateBaseVertices(int noOfDimensions)
        {
            //set no of vertices to 2^no of dimensions
            int noOfVertices = (int)Math.Pow(2, noOfDimensions);
           
            //create vertex base array 
            int[,] verticesBase = new int[noOfVertices, noOfDimensions];

            for (int i = 1; i <= noOfVertices; i++)
            {
                for (int j = 1; j <= noOfDimensions; j++)
                {
                    //determines if result of formula is odd or even
                    if (((int)Math.Pow(2, j) * i / noOfVertices) % 2 == 0)
                    {
                        //if even then set value to 1
                        verticesBase[i-1, j-1] = 1;
                    }
                    else
                    {
                        //if odd set value to -1
                        verticesBase[i-1, j-1] = -1;
                    }

                }
            }

            return verticesBase;
        }
    }
}