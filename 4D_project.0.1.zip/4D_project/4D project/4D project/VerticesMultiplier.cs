﻿using System;

namespace Generator
{
    public class VerticesMultiplier
    {
        
        public static float[] verticesMultiplier(int[] userInputData)
        {
            //create array of floats, one for each dimension
            float[] verticesRotationMultiplier = new float[userInputData[0]];
            //convert degrees to radians
            float angleRadians = userInputData[2] * (float)Math.PI / 180;
            //set all rotation multipliers to one
            for (int i = 0; i < userInputData[0]; i++)
            {
                verticesRotationMultiplier[i] = 1;
            }
            //set first axis rotation multiplier
            verticesRotationMultiplier[userInputData[3]] = (float)(Math.Cos(angleRadians) - Math.Sin(angleRadians));
            //set first axis rotation multiplier
            verticesRotationMultiplier[userInputData[4]] = (float)(Math.Cos(angleRadians) + Math.Sin(angleRadians));
            return verticesRotationMultiplier;
        }
    }
}
