﻿using System;


namespace Generator
{
    public class PrintArray
    {
        public static void printArrayInt(int[,] inputArray)
        {
            int columnLength = inputArray.GetLength(1);
            int rowLength = inputArray.GetLength(0);

            for (int i = 0; i < rowLength; i++)
            {
                //for each axis
                for (int j = 0; j < columnLength; j++)
                {
                    //write the coordinate to console
                    Console.Write(inputArray[i, j]);
                    //add space
                    Console.Write(" ");
                }
                //new line for each vertex
                Console.WriteLine(" ");
            }
            Console.WriteLine();
            return;
        }
        public static void printArrayFloat(float[,] inputArray)
        {
            int columnLength = inputArray.GetLength(1);
            int rowLength = inputArray.GetLength(0);

            for (int i = 0; i < rowLength; i++)
            {
                //for each axis
                for (int j = 0; j < columnLength; j++)
                {
                    //write the coordinate to console
                    Console.Write(inputArray[i, j]);
                    //add space
                    Console.Write(" ");
                }
                //new line for each vertex
                Console.WriteLine();
            }
            Console.WriteLine();
            return;
        }
    }
}