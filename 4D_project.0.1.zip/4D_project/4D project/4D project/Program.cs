﻿using System;



namespace Generator
{
   
    class MainClass
    {
        static void Main()
        {
            //get basic information and save as variables
            UserInput userInput = new UserInput();
            int[] userInputData = userInput.userInput();
            int noOfDimensions = userInputData[0];
            int hyperCubeLength = userInputData[1];
            

            //gets array of values to multiply axis by to account for edge length and rotation and returns array
            float[] verticesMultiplier = VerticesMultiplier.verticesMultiplier(userInputData);
            //creates array of 1's and -1's for positive and negative coordinates and returns array
            int[,] verticesBase = CalculateBaseVertices.calculateBaseVertices(noOfDimensions);
            //multiplies each entry in verticesBase by the verticesMultiplier for that axis and returns array
            float[,] verticesNew = CalculateVertices.calculateVertices(verticesMultiplier, verticesBase, hyperCubeLength);
            //creates 2Darray of 2 integers, each one points to location of a vertex in verticesNew and verticesBase array
            int[,] edgesBase = CalculateBaseEdges.calculateBaseEdges(verticesBase);
            //print calculated vertices          
            PrintArray.printArrayFloat(verticesNew);
            //print array of edge location pointers
            PrintArray.printArrayInt(edgesBase);
            //save as integer number of vertices
            int noOfVertices = verticesBase.GetLength(0);
            //save as integer number of edges
            int noOfEdges = edgesBase.GetLength(0);
            //print out information
            Console.WriteLine("Dimensions = {0}", userInputData[0]);
            Console.WriteLine("Edge length = {0}", userInputData[1]);
            Console.WriteLine("First axis of rotation = {0}", userInputData[3]);
            Console.WriteLine("Second axis of rotation = {0}", userInputData[4]);
            Console.WriteLine("{0}", noOfVertices + " Vertices");
            Console.WriteLine("{0}", noOfEdges + " Edges");

        }
    }
}


